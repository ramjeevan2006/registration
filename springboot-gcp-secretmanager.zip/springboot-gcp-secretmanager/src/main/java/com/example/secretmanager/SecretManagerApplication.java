
package com.example.secretmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SecretManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecretManagerApplication.class, args);
    }

    @Bean
    CommandLineRunner runner(@Value("${test.secret}") String secret) {
        return args -> {
            System.out.println("Fetched secret: " + secret);
        };
    }
}
