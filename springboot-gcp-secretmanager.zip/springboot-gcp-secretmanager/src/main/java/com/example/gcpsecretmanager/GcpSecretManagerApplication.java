
package com.example.gcpsecretmanager;

import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.cloud.secretmanager.v1.SecretVersionName;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class GcpSecretManagerApplication {

    private static final Logger logger = LogManager.getLogger(GcpSecretManagerApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(GcpSecretManagerApplication.class, args);
        logger.info("Application started successfully.");
    }

    @Bean
    public void fetchSecret(Environment environment) {
        String projectId = environment.getProperty("spring.cloud.gcp.project-id");
        String secretId = environment.getProperty("gcp.secret.id");
        String versionId = "latest";

        if (projectId == null || secretId == null) {
            logger.error("Project ID or Secret ID is not set in application.properties");
            return;
        }

        try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
            SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, versionId);
            AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);

            String secretData = response.getPayload().getData().toStringUtf8();
            logger.info("Fetched secret value: {}", secretData);
        } catch (Exception e) {
            logger.error("Error fetching secret: ", e);
        }
    }
}
